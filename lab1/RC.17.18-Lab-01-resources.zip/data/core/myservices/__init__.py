"""myservices

Custom services that you define can be put in this directory.  Everything
listed in __all__ is automatically loaded when you add this directory to the
custom_services_dir = '/full/path/to/here' core.conf file option.
"""
__all__ = ["trafficdump", "tracker", "tracker2", "peerseeder", "peerplay00", "peerplay01", "peerplay02", "peerplay03", "peerplay04", "peerplay05", "peerplay05half1", "peerplay05half2", "peerplay10","peerplay30", "peerplay31", "peerplay32", "peerplay33", "peerplaytest", "linkadsl_u128k", "linkadsl_u256k", "linkadsl_u512k", "linkadsl_u768k", "linkadsl_u1024k", "linkbw4g_u5800k", "linkcable_u8000k", "simplenat"]
